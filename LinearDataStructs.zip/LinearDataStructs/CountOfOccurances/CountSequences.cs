﻿namespace CountOfOccurances
{
    using System;
    using System.Linq;
    using SharedParser;
    using System.Collections.Generic;

    //Write a program that finds in given array of integers 
    //how many times each of them occurs.The input sequence holds numbers in range[0…1000]. 
    //The output should hold all numbers that occur at least once along with their number of occurrences.

    class CountSequences
    {
        static void Main()
        {
            Dictionary<int,int> counts = new Dictionary<int, int>();
            List<int> numbers = InputParser.GetIntegersFromConsole();
            foreach (int number in numbers)
            {
                Action action = counts.ContainsKey(number) 
                                ? (Action) (() => { counts[number]++; } )
                                : (() => { counts.Add(number, 1); });
                action();
            }
            Console.WriteLine("{0}", String.Join("\n", counts.OrderBy(kvp => kvp.Key).Select(kvp => kvp.Key + " -> " + kvp.Value + " times ")));
        }
    }
}
