﻿namespace DistanceInLabyrinth
{
    using System;
    using System.Collections.Generic;

    //Bug due to being char array => Wont show 10, shows 1 instead.
    //Hardcoding it because fuck it it's 1 AM.
    //The algorithm is called 4-directional BFS and this is a horrible but functional implementation of it.

    class DistanceInLabyrinth
    {
        static void Main(string[] args)
        {
            char[,] labyrinth = { {'0','0','0','x','0','x'},
                                  {'0','x','0','x','0','x'},
                                  {'0','s','x','0','x','0'},
                                  {'0','x','0','0','0','0'},
                                  {'0','0','0','x','x','0'},
                                  {'0','0','0','x','0','x'}};
            var traversedLab = TraverseLabyrinth(labyrinth);

            for (int i = 0; i < labyrinth.GetLength(0); i++)
            {
                for (int j = 0; j < labyrinth.GetLength(1); j++)
                {
                    Console.Write(" {0}", traversedLab[i,j] == '0' ? 'u' : traversedLab[i,j]);
                }
                Console.Write("\n");
            }
            Console.ReadKey();
        }

        static char[,] TraverseLabyrinth(char[,] input, int iteration = 0)
        {
            List<int[]> indexesToChange = new List<int[]>();
            bool foundS = false;
            for (int y = 0; y < input.GetLength(0); y++)
            {
                for (int x = 0; x < input.GetLength(1); x++)
                {
                    if (input[y, x] == 's')
                    {
                        foundS = true;
                        input[y, x] = iteration.ToString()[0] == '0' ? '*' : iteration.ToString()[0];
                        if (y < input.GetLength(0) - 1)
                        {
                            if (input[y + 1, x] == '0')
                            {
                                indexesToChange.Add(new[] {y + 1, x});
                            }
                        }
                        if (y > 0) { 
                            if (input[y - 1, x] == '0')
                            {
                                indexesToChange.Add(new[] { y - 1, x });
                            }
                        }
                        if (x > 0 )
                        {
                            if (input[y , x - 1] == '0')
                            {
                                indexesToChange.Add(new []{y,x-1});
                            }
                        }
                        if (x < input.GetLength(0) - 1)
                        {
                            if (input[y, x + 1] == '0')
                            {
                                indexesToChange.Add(new[] { y, x + 1 });
                            }

                        }
                    }
                }
            }
            if (!foundS)
            {
                return input;
            }
            for (int i = 0; i < indexesToChange.Count; i++)
            {
                input[indexesToChange[i][0], indexesToChange[i][1]] = 's';
            }
            iteration++;
            return TraverseLabyrinth(input, iteration);
        }
    }
}
