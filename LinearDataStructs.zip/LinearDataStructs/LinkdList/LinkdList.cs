﻿namespace LinkdList
{
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    public class LinkdList<T> : IEnumerator, IEnumerable
    {
        private List<LinkdNode<T>> items;
        private int pos;

        public LinkdList()
        {
            items = new List<LinkdNode<T>>();
        }

        public void Add(T item)
        {
            items.Last().Next = new LinkdNode<T>(item);
        }

        public void Remove(int index)
        {
            items.RemoveAt(index);
        }

        public int Count { get { return items.Count; } }

        public int FirstIndexOf(T item)
        {
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].Item.Equals(item))
                {
                    return i;
                }
            }
            return -1;
        }

        public int LastIndexOf(T item)
        {
            for (int i = items.Count-1; i >= 0; i--)
            {
                if (items[i].Item.Equals(item))
                {
                    return i;
                }
            }
            return -1;
        }

        public IEnumerator GetEnumerator()
        {
            return (IEnumerator) this;
        }

        public bool MoveNext()
        {
            pos += 1;
            return pos < items.Count;
        }

        public void Reset()
        {
            pos = 0;
        }

        public object Current { get { return items[pos]; } }
    }
}
