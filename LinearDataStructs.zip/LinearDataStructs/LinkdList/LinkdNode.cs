﻿namespace LinkdList
{
    class LinkdNode<T>
    {
        public LinkdNode(T item)
        {
            this.Item = item;
        }
        public T Item;

        public LinkdNode<T> Next;
    }
}