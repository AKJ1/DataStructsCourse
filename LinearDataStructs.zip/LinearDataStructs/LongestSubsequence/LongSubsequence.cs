﻿namespace LongestSubsequence
{
    using System;
    using SharedParser;
    using System.Collections.Generic;

    //Write a method that finds the longest subsequence of equal numbers in given List<int> 
    //and returns the result as new List<int>. If several sequences has the same longest length
    //return the leftmost of them. Write a program to test whether the method works correctly. 

    class LongSubsequence
    {
        static void Main()
        {
            List<int> numbers = InputParser.GetIntegersFromConsole();
            numbers.Sort();
            Console.WriteLine(String.Join(" ", LongestSequence(numbers)));
        }

        static List<int> LongestSequence(List<int> numbers)
        {
            int start = 0, longest = 0, last = -1, currentCnt = 1;
            for (int i = 0; i < numbers.Count; i++)
            {
                if (last != numbers[i])
                {
                    if (currentCnt > longest)
                    {
                        start = i - currentCnt;
                        longest = currentCnt;
                    }
                    currentCnt = 1;
                }
                else
                {
                    currentCnt++;
                    if (i == numbers.Count - 1 && currentCnt > longest)
                    {
                        start = (i - currentCnt) + 1;
                        longest = currentCnt;
                    }
                }
                last = numbers[i];
            }
            return numbers.GetRange(start, longest);
        }
    }
}
