﻿namespace RemoveOddOccurences
{
    using System;
    using System.Linq;
    using SharedParser;
    using System.Collections.Generic;

    // Write a program that removes from given sequence
    // all numbers that occur odd number of times.
    class RemoveOddOccurences
    {
        static void Main()
        {
            List<int> numbers = InputParser.GetIntegersFromConsole();
            List<int> returnVals = new List<int>(numbers.ToArray());
            for (int i = 0; i < numbers.Count; i++)
            {
                if (numbers.Count(n => n == numbers[i])%2 != 0)
                {
                    returnVals.RemoveAll(n => n == numbers[i]);
                }
            }
            Console.WriteLine(String.Join(" " ,returnVals));
        }
    }
}