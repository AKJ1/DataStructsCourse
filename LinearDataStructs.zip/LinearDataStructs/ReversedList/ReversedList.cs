﻿namespace ReversedList
{
    using System;
    using System.Collections;

    public class ReversedList<T> : IEnumerator, IEnumerable
    {
        public int Capacity { get; protected set; }
        public int Count { get; protected set; }

        private int enumPos = 0;

        T[] items;

        public ReversedList()
        {
            Count = 0;
            Capacity = 16;
            items = new T[Capacity];
        } 

        public void Add(T item)
        {
            if (Count == Capacity)
            {
                Resize();
            }
            else
            {
                items[Count] = item;
                Count++;
            }
        }

        private void Resize()
        {
            Capacity *= 2;
            T[] newArr = new T[Capacity];
            Array.Copy(items, newArr, Count-1);
            items = newArr;
        }

        public void Remove(int position)
        {
            T[] firstHalf = new T[Count-(position-1)];
            Array.Copy(items, 0, firstHalf, 0, Count - (position - 1));

            T[] secondHalf = new T[position];
            Array.Copy(items, Count - position, secondHalf , 0,position);

            items = new T[Count-1];
            Array.Copy(firstHalf, items, firstHalf.Length);
            Array.Copy(secondHalf, 0, items, position, secondHalf.Length);
            Count--;
        }

        public T this[int i]
        {
            get { return items[Count-i]; }
            set { items[Count-i] = value; }
        }

        public bool MoveNext()
        {
            enumPos++;
            return enumPos < Count;
        }

        public void Reset()
        {
            enumPos = 0;
        }

        public object Current { get { return this[enumPos]; } }

        public IEnumerator GetEnumerator()
        {
            return (IEnumerator) this;
        }
    }
}
