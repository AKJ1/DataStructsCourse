﻿

namespace SharedParser
{
    using System;

    using System.Linq;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;
    public static class InputParser
    {
        public static List<int> GetIntegersFromConsole()
        {
            string input = Console.ReadLine();
            if (!input.Contains(' ') || String.IsNullOrEmpty(input) || Regex.IsMatch(input, "(?![ 0-9])."))
            {
                Console.WriteLine("Try again.");

                return GetIntegersFromConsole();
            }
            input = input.Trim();
            return Array.ConvertAll(input.Split(' '), s => int.Parse(s)).ToList();
        }

        public static List<string> GetStringsFromConsole()
        {
            string input = Console.ReadLine();
            if (String.IsNullOrEmpty(input))
            {
                Console.WriteLine("Try again.");
                return GetStringsFromConsole();
            }
            return input.Split(' ').ToList();
        }
    }
}
