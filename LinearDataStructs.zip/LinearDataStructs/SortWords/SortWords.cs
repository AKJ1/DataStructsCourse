﻿namespace SortWords
{
    using System;
    using SharedParser;
    using System.Collections.Generic;
    
    // Write a program that reads from the console a sequence of words
    // (strings on a single line, separated by a space). Sort them alphabetically. 
    // Keep the sequence in List<string>.
    class SortWords
    {
        static void Main()
        {
            List<string> splitString = InputParser.GetStringsFromConsole();
            splitString.Sort(StringComparer.InvariantCultureIgnoreCase);
            Console.WriteLine(String.Join(" ", splitString.ToArray()));
        }
    }
}