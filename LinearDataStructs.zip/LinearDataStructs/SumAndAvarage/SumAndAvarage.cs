﻿namespace SumAndAvarage
{
    using System;
    using SharedParser;
    using System.Collections.Generic;

    // Write a program that reads from the console a sequence of integer numbers 
    // (on a single line, separated by a space).
    // Calculate and print the sum and average of the elements of the sequence.
    // Keep the sequence in List<int>.

    class SumAndAvarage
    {
        static void Main()
        {
            List<int> numbers = InputParser.GetIntegersFromConsole();
            long product = 0;
            foreach (int i in numbers) product += i;
            Console.WriteLine("Sum={0}; Avarage={1}",product, (product/(float)numbers.Count));
        }
    }
}
